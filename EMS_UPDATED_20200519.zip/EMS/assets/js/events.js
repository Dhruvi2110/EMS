$(document).ready(function () {
    $("#btnShow").click(function () {
        jQuery.ajax({
            type: "POST",
            url: 'class.reg.php',
            async: false,
            data: {function: 'getData'},
            success: function (response) {
                if (response) {
                    var result = JSON.parse(response);
                    if (result.status == 1) { 
                        var data = result.data;
                        
                        $.each(data,function(key,val){
                            var appendStr='';
                            appendStr='<tr><td>'+val.name+'</td><td>'+val.email+'</td></tr>';
                            $('#listData').append(appendStr);
                        });
                        
                    }
                }
            }
        });
    });
    
});