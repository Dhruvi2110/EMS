<?php

namespace Phppot;

class Event {

    private $ds;

    function __construct() {
        require_once __DIR__ . './../lib/DataSource.php';
        $this->ds = new DataSource();
    }

    public function addEvent() {
        session_start();
        $query = 'INSERT INTO event_detail (event_name, start_date, end_date, status, created_by,assigned_to) VALUES (?, ?, ?, ?, ?,?)';
        $paramType = 'ssssss';
        $paramValue = array(
            $_POST["event_name"],
            $_POST["start_date"],
            $_POST["end_date"],
            1,
            $_SESSION["userid"],
            ''
        );
        $memberId = $this->ds->insert($query, $paramType, $paramValue);
        if (!empty($memberId)) {
            $response = array("status" => "success", "message" => "Event created successfully.");
        } else {
            $response = array("status" => "success", "message" => "Event Not created successfully.");
        }

        return $response;
    }

    public function getAllEventsByUserid($userid) {
        $query = 'SELECT * FROM event_detail where created_by = ? UNION ALL SELECT ed.* FROM event_detail ed INNER JOIN event_sharing es ON ed.id = es.event_id where es.user_id = ?';
        $paramType = 'ss';
        $paramValue = array(
            $userid,
            $userid
        );
        $eventDetail = $this->ds->select($query, $paramType, $paramValue);
        return $eventDetail;
    }

    public function getUsers($userid) {
        $query = 'SELECT * FROM users where id <> ?';
        $paramType = 's';
        $paramValue = array(
            $userid
        );
        $userList = $this->ds->select($query, $paramType, $paramValue);
        return $userList;
    }

    public function getUsersWithEventid($event_id, $userid) {
        $query = 'SELECT * FROM event_sharing where user_id = ? AND event_id= ?';
        $paramType = 'ss';
        $paramValue = array(
            $userid,
            $event_id
        );
        $userWithEvent = $this->ds->select($query, $paramType, $paramValue);
        return $userWithEvent;
    }

    public function shareEvent($eventid, $user_id, $emailid) {

//        $queryU = 'SELECT * FROM event_sharing where user_id = ? AND event_id= ?';
//        $paramTypeU = 'ss';
//        $paramValueU = array(
//            $user_id,
//            $eventid
//        );
//        $userWithEvent = $this->ds->select($queryU, $paramTypeU, $paramValueU);
//        if (!empty($userWithEvent)) {
//            $response = array("status" => "success", "message" => "This event is already shared to this user.");
//            return $response;
//        } else {

        $query = 'INSERT INTO event_sharing (event_id, user_id) VALUES (?, ?)';
        $paramType = 'ss';
        $paramValue = array(
            $eventid,
            $user_id
        );
        $userList = $this->ds->insert($query, $paramType, $paramValue);


        if (!empty($userList)) {
            $logged_in_userid = $_SESSION['userid'];
            $query1 = 'SELECT email FROM users where id = ?';
            $paramType1 = 's';
            $paramValue1 = array(
                $logged_in_userid
            );

            $from_email_id = $this->ds->select($query1, $paramType1, $paramValue1);

            $from = $from_email_id[0]['email'];

            $subject = "Event Notification";

            $message = "<b>This is HTML message.</b>";
            $message .= "<h1>This is headline.</h1>";

            $header = "From:" . $from . " \r\n";
            $header .= "MIME-Version: 1.0\r\n";
            $header .= "Content-type: text/html\r\n";

            $retval = mail($emailid, $subject, $message, $header);
            header("location:share-event.php?eventid=" . $eventid);
        }
//        }
    }

}
