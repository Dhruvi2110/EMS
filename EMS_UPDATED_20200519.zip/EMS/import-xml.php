<?php
$conn = new mysqli("localhost", "root", "", "event_management");
$affectedRow = 0;
$xml = simplexml_load_file("product.xml") or die("Error: Cannot create object");
foreach ($xml->children() as $row) {
    $prod_desc = $row['description'];
    $prod_img = $row['product_image'];
    /* Insert Products from here */
    $sql = "INSERT INTO products(description,product_image) VALUES ('" . $prod_desc . "','" . $prod_img . "')"; 
    $result = $conn->query($sql);
    $inserted_product_id = $conn->insert_id;
    $catelog_data = $row->catalog_item;
    foreach ($catelog_data as $single_catalog_data) {
        $gender = $single_catalog_data['gender'];
        $item_num_array = $single_catalog_data->item_number;
        $item_price_array = $single_catalog_data->price;
        $item_size_array = $single_catalog_data->size;
        $item_size = count($item_num_array);
        for ($i = 0; $i < $item_size; $i++) {
            $item_number = $item_num_array[$i]->__toString();
            $item_price = $item_price_array[$i]->__toString();
            /* Insert catalog items from here */
            $sql = "INSERT INTO catalog_item(product_id,gender,item_number,price) VALUES ('" . $inserted_product_id . "','" . $gender . "','" . $item_number . "','" . $item_price . "')"; 
            $result = $conn->query($sql);
            $inserted_catalog_id = $conn->insert_id;
            for ($j = 0; $j < count($item_size_array[$i]); $j++) {
                $item_color_array = $item_size_array[$j]->color;
                $size_description = $item_size_array[$j]['description']->__toString();
                /* Insert items size detail from here */
                $size_sql = "INSERT INTO size(catalog_item_id,description) VALUES ('" . $inserted_catalog_id . "','" . $size_description . "')";
                $result = $conn->query($size_sql);
                $inserted_size_id = $conn->insert_id;
                for ($k = 0; $k < $item_color_array->count(); $k++) {
                    $size_color = $item_color_array[$k]->__toString();
                    /* Insert items color detail from here */
                    $color_sql = "INSERT INTO color(size_id,description) VALUES ('" . $inserted_size_id . "','" . $size_color . "')";
                    $result = $conn->query($color_sql);
                }
            }
        }
    }
    if (! empty($result)) {
        $affectedRow ++;
    } else {
        $error_message = $conn-> connect_error. "\n";
    }
}
if ($affectedRow > 0) {
    $message =  "All records are inserted successfully";
} else {
    $message = "No records inserted";
}
?>
<style>
    body {  
        max-width:550px;
        font-family: Arial;
    }
    .affected-row {
        background: #cae4ca;
        padding: 10px;
        margin-bottom: 20px;
        border: #bdd6bd 1px solid;
        border-radius: 2px;
        color: #6e716e;
    }
    .error-message {
        background: #eac0c0;
        padding: 10px;
        margin-bottom: 20px;
        border: #dab2b2 1px solid;
        border-radius: 2px;
        color: #5d5b5b;
    }
</style>
<div class="affected-row"><?php  echo $message; ?></div>
<?php if (! empty($error_message)) { ?>
<div class="error-message"><?php echo nl2br($error_message); ?></div>
<?php } ?>