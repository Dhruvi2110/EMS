<?php

use Phppot\Event;

$user_id = $_GET['userid'];
$eventid = $_GET['eventid'];
$emailid = $_GET['emailid'];
session_start();
$username = $_SESSION["username"];
$userid = $_SESSION["userid"];
require_once './Model/Event.php';
$event = new Event();
$userListResponse = $event->shareEvent($eventid,$user_id,$emailid);
?>
