<?php

use Phppot\Event;

$event_id = $_GET['eventid'];
session_start();
$username = $_SESSION["username"];
$userid = $_SESSION["userid"];
require_once './Model/Event.php';
$event = new Event();
$userListResponse = $event->getUsers($userid, $event_id);
?>
<html>
    <HEAD>
        <TITLE>Share Event</TITLE>
        <link href="./assets/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
        <link href="./assets/css/style.css" type="text/css" rel="stylesheet" />
        <link href="./assets/css/phppot-style.css" type="text/css" rel="stylesheet" />

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    </HEAD>
    <body>
        <div class="wrapper" style="height: auto; min-height: 100%;">
            <HEADER class="main-header">
                <div class="pull-right">
                    <?php echo $username; ?> <a href="index.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
            </HEADER>

            <div class="content-wrapper">
                <section class="content">
                    <DIV class="row">
                        <div class="col-md-12">
                            <div class="box">
                                <div class="box-header">
                                    <h3 class="box-title">Users</h3>

                                </div>
                                <div class="box-body table-responsive no-padding">
                                    <table class="table table-hover">
                                        <tbody>
                                            <tr>
                                                <th>User Name</th>
                                                <th>User Email</th>
                                                <th></th>
                                            </tr>

                                            <?php
                                            if (!empty($userListResponse)) { 
                                                foreach ($userListResponse as $user) { 
                                                    $userWithEvent = $event->getUsersWithEventid($event_id, $user['id']);
                                                    if (empty($userWithEvent)) {
                                                        ?>
                                                        <tr>
                                                            <td><?php echo($user['username']); ?></td>
                                                            <td><?php echo($user['email']); ?></td>
                                                            <td><a href="delete.php?userid=<?php echo $user['id']; ?>&eventid=<?php echo $event_id; ?>&emailid=<?php echo $user['email']; ?>">Share Event</a></td>
                                                        </tr>
                                                    <?php }
                                                    ?>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </tbody></table>
                                </div>
                            </div>
                        </div>
                    </DIV>
                </section>
            </div>
        </div>
    </body>
</html>
