<?php

use Phppot\Event;

if (!empty($_POST["add-event-btn"])) {
    require_once './Model/Event.php';
    $event = new Event();
    $addEventResponse = $event->addEvent();
}
?>
<html>
    <HEAD>
        <TITLE>Create Event</TITLE>
        <link href="./assets/css/phppot-style.css" type="text/css"
              rel="stylesheet" />
        <link href="./assets/css/user-registration.css" type="text/css"
              rel="stylesheet" />
        <link href="./assets/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
        <script src="./vendor/jquery/jquery-3.3.1.js" type="text/javascript"></script>
    </HEAD>
    <body>
        <div class="wrapper" style="height: auto; min-height: 100%;">
            <HEADER class="main-header">
                <div class="pull-right">
                     <a href="index.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
            </HEADER>

            <div class="content-wrapper">
                <div class="content">
                    
                </div>
            </div>


            <div class="phppot-container">
                <div class="sign-up-container">
                    <div class="signup-align">
                        <form name="addEvent" action="" method="post" onsubmit="return eventValidation()">
                            <div class="signup-heading">Create Event</div>
                            <div class="error-msg" id="error-msg"></div>
                            <div class="row">
                                <div class="inline-block">
                                    <div class="form-label">
                                        Event Name<span class="required error" id="eventname-info"></span>
                                    </div>
                                    <input class="input-box-330" type="text" name="event_name"
                                           id="event_name">
                                </div>
                            </div>
                            <div class="row">
                                <div class="inline-block">
                                    <div class="form-label">
                                        Start Date<span class="required error" id="startdate-info"></span>
                                    </div>
                                    <input class="input-box-330" type="date"
                                           name="start_date" id="start_date">
                                </div>
                            </div>
                            <div class="row">
                                <div class="inline-block">
                                    <div class="form-label">
                                        End Date<span class="required error" id="enddate-info"></span>
                                    </div>
                                    <input class="input-box-330" type="date"
                                           name="end_date" id="end_date">
                                </div>
                            </div>
                            <div class="row">
                                <input class="sign-up-btn" type="submit" name="add-event-btn"
                                       id="add-event-btn" value="Create Event">


                            </div>

                            <div class="row">
                                <a href="home.php"><input class="sign-up-btn" type="button" name="show-event-btn"
                                                          id="add-event-btn" value="Show Events"></a>
                            </div>

                        </form>
                    </div>
                </div>
            </div>

            <script>


                function eventValidation() {
                    var valid = true;
                    $("#event_name").removeClass("error-field");
                    $("#start_date").removeClass("error-field");
                    $("#end_date").removeClass("error-field");

                    var eventname = $("#event_name").val();
                    var startdate = $("#start_date").val();
                    var enddate = $('#end_date').val();

                    $("#eventname-info").html("").hide();
                    $("#startdate-info").html("").hide();
                    $("#enddate-info").html("").hide();


                    if (eventname.trim() == "") {
                        $("#eventname-info").html("required.").css("color", "#ee0000").show();
                        $("#event_name").addClass("error-field");
                        valid = false;
                    }

                    var sDate = new Date($('#start_date').val());
                    var eDate = new Date($('#end_date').val());

                    if (startdate.trim() == "") {
                        $("#startdate-info").html("required").css("color", "#ee0000").show();
                        $("#start_date").addClass("error-field");
                        valid = false;
                    }
                    if (enddate.trim() == "") {
                        $("#enddate-info").html("required.").css("color", "#ee0000").show();
                        $("#end_date").addClass("error-field");
                        valid = false;
                    } else if (eDate < new Date()) {
                        $("#error-msg").html("End date should not be smaller than today.").show();
                        valid = false;
                    }

                    if (sDate > eDate) {
                        $("#error-msg").html("Start date should not be greater than end date.").show();
                        valid = false;
                    }

                    if (valid == false) {
                        $('.error-field').first().focus();
                        valid = false;
                    }
                    return valid;
                }
            </script>

    </body>
</html>


