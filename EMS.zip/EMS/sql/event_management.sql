-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2020 at 06:35 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `event_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `event_detail`
--

CREATE TABLE `event_detail` (
  `id` int(11) NOT NULL,
  `event_name` varchar(200) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` int(11) NOT NULL COMMENT '1 - Active\r\n2 - In-active',
  `created_by` int(11) NOT NULL,
  `assigned_to` varchar(300) NOT NULL COMMENT 'comma separated array of user-ids to which this event is assigned'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event_detail`
--

INSERT INTO `event_detail` (`id`, `event_name`, `start_date`, `end_date`, `status`, `created_by`, `assigned_to`) VALUES
(15, 'Event Garba', '2020-05-16', '2020-05-30', 1, 3, ''),
(16, 'Event Gate to Gather', '2020-05-23', '2020-05-23', 1, 3, '');

-- --------------------------------------------------------

--
-- Table structure for table `event_sharing`
--

CREATE TABLE `event_sharing` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event_sharing`
--

INSERT INTO `event_sharing` (`id`, `event_id`, `user_id`) VALUES
(19, 15, 4),
(20, 15, 6),
(21, 16, 5);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `create_at`) VALUES
(3, 'Dhruvi', '$2y$10$ZwEzubT8ZwKNzvoae36sdeOoK78wH.NS0gi68BHmlTZwcrLP8AR6S', 'shahdhruvi9320@yahoo.com', '2020-05-16 13:40:17'),
(4, 'Nilang', '$2y$10$9r0b381/8Vjk.0HbayBy6.rUN1c1UxxGwkKYL9cH88IZRzLuFrtea', 'nilang134@gmail.com', '2020-05-16 15:50:59'),
(5, 'Darshil', '$2y$10$uKXdkE3s7f2CwWMhFXuXW.Z7TPbi0G6hPzS0vzzRBnV/Gn9scfbGi', 'darshil.shah@gmail.com', '2020-05-16 16:32:14'),
(6, 'Sachin', '$2y$10$WzXefzDc0IqApLebZ02Lpu9qiEq1dymsjPDnOb0KzaybOGJv3LkVu', 'sachin@gmail.com', '2020-05-16 16:32:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `event_detail`
--
ALTER TABLE `event_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_sharing`
--
ALTER TABLE `event_sharing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `event_detail`
--
ALTER TABLE `event_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `event_sharing`
--
ALTER TABLE `event_sharing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
