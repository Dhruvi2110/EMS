<?php
session_start();
$username = $_SESSION["username"];
$userid = $_SESSION["userid"];

use Phppot\Event;

require_once './Model/Event.php';
$event = new Event();
$addEventResponse = $event->getAllEventsByUserid($userid);
?>
<HTML>
    <HEAD>
        <TITLE>Welcome</TITLE>
        <!--        <link href="./assets/css/user-registration.css" type="text/css" rel="stylesheet" />-->
        <link href="./assets/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
        <link href="./assets/css/style.css" type="text/css" rel="stylesheet" />
        <link href="./assets/css/phppot-style.css" type="text/css" rel="stylesheet" />

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <!--        <link href="./assets/css/ionicons.min.css" type="text/css" rel="stylesheet" />
        <script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>-->

    </HEAD>
    <BODY>
        <div class="wrapper" style="height: auto; min-height: 100%;">
            <HEADER class="main-header">
                <div class="pull-right">
                    <?php echo $username; ?> <a href="index.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
            </HEADER>

            <div class="content-wrapper">
                <SECTION class="content">
                    <DIV class="row">
                        <div class="col-md-12">
                            <div class="box">
                                <div class="box-header">
                                    <h3 class="box-title">Events</h3>

                                    <div class="box-tools">
                                        <div class="input-group input-group-sm hidden-xs" style="width: 150px;">
                                            <a href="add-event.php" class="pull-right">
                                                Create Event
                                                <i class="fa fa-plus"></i></a>
                                        </div>
                                    </div>
                                </div>

                                <div class="box-body table-responsive no-padding">
                                    <table class="table table-hover">
                                        <tbody>
                                            <tr>
                                                <th>Sr no.</th>
                                                <th>Event Name</th>
                                                <th>Start Date</th>
                                                <th>End Date</th>
                                                <th></th>
                                            </tr>

                                            <?php
                                            if (!empty($addEventResponse)) {
                                                foreach ($addEventResponse as $product) {
                                                    $event_id = $product['id'];
                                                    ?>
                                                    <tr>
                                                        <td><?php echo($product['id']); ?></td>
                                                        <td><?php echo($product['event_name']); ?></td>
                                                        <td><?php echo($product['start_date']); ?></td>
                                                        <td><?php echo($product['end_date']); ?></td>
                                                        <td><a href="share-event.php?eventid=<?php echo $event_id; ?>" class="text-center">
                                                                <i class="fa fa-share-alt" aria-hidden="true"></i></a>
                                                        </td>
                                                        <?php
                                                    }
                                                } else {
                                                    ?>
                                                <tr><td colspan="5" >No record found</td></tr>
                                                <?php
                                            }
                                            ?>
                                        </tbody></table>
                                </div>
                            </div>
                        </div>
                    </DIV>
                </SECTION>
            </div>

        </div>
    </BODY>
</HTML>